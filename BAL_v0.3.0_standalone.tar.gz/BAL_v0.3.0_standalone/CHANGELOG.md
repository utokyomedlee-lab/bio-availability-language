# Changelog

## 0.3.0

- Introduce the normalized nonlinear bioavailability core.
- Add DDS, gut, liver, plasma, and tissue compartments.
- Add dynamic tolerance feedback and optional recovery.
- Add RK4 integration and explicit mass-balance reporting.
- Add reproducible Monte Carlo scenario analysis.
- Add standalone CLI, tests, documentation, and GitHub Actions CI.
- Establish BAL as an independent project separate from BPL.
