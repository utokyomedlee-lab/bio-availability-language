# BAL 0.3.0 — Bio-Availability Language

**BAL (Bio-Availability Language)** is an independent domain-specific research
runtime for normalized bioavailability modeling and multi-compartment DDS
simulation. It is a separate project from BPL: it has its own package, CLI,
model schema, tests, documentation, and release lifecycle.

## Features

- Normalized nonlinear BAL bioavailability kernel
- DDS depot release with a decaying initial burst
- Gut absorption and degradation
- Hepatic first-pass metabolism / escape approximation
- Plasma–tissue exchange and elimination
- Dynamic tolerance feedback and recovery
- Classical fourth-order Runge–Kutta integration
- Explicit mass-balance accounting
- Reproducible uniform-range Monte Carlo scenario analysis
- CSV and JSON output

## Install from source

Python 3.10 or newer is required. The runtime has no third-party runtime dependencies.

```bash
git clone https://github.com/utokyomedlee-lab/bio-availability-language.git
cd bio-availability-language
python -m pip install -e .
```

## Run the reference scenario

```bash
bal-sim --config examples/bal_multicompartment.json \
  --output results.csv \
  --uncertainty-output uncertainty.json
```

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Mathematical kernel

Let `A = alpha * a * (1 - m)`:

`y(t) = ln(1 + A) / ln(1 + beta*b(t))`

The model-defined threshold `y > 1` is equivalent to `A > beta*b(t)`.

The full state model includes DDS depot (`D`), gut (`G`), liver (`H`), plasma
(`P`), tissue (`T`), cumulative loss states, and tolerance (`b`). See
[`docs/BAL_v0.3_KO.md`](docs/BAL_v0.3_KO.md) for the equations and assumptions.

## Scientific scope

BAL 0.3.0 is an executable research software prototype. Reference parameters
are synthetic demonstration values, not experimentally measured or clinically
validated estimates. The model is not a dosing calculator or treatment
recommendation system. Model calibration and external experimental validation
are required before biological interpretation.

## Relationship to BPL

BAL is an independent language project. It does not import BPL, depend on the
BPL runtime, or require the `bio-function` repository. Interoperability, if
introduced later, should use a neutral data-exchange format only.
